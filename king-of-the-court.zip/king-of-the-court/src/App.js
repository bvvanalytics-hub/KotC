import React, { useState, useEffect } from "react";

export default function KingOfTheCourtTracker() {
  const [teams, setTeams] = useState([]);
  const [queue, setQueue] = useState([]);
  const [king, setKing] = useState(null);
  const [queen, setQueen] = useState(null);
  const [points, setPoints] = useState({});
  const [newTeam, setNewTeam] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("koc_game");
    if (saved) {
      const data = JSON.parse(saved);
      setTeams(data.teams || []);
      setQueue(data.queue || []);
      setKing(data.king || null);
      setQueen(data.queen || null);
      setPoints(data.points || {});
    }
  }, []);

  const saveGame = () => {
    const data = { teams, queue, king, queen, points };
    localStorage.setItem("koc_game", JSON.stringify(data));
    alert("Spielstand gespeichert!");
  };

  const clearGame = () => {
    localStorage.removeItem("koc_game");
    setTeams([]);
    setQueue([]);
    setKing(null);
    setQueen(null);
    setPoints({});
    alert("Spielstand gelöscht.");
  };

  const addTeam = () => {
    if (!newTeam.trim()) return;
    const team = newTeam.trim();
    const updated = [...teams, team];
    setTeams(updated);
    setQueue(updated);
    setPoints((prev) => ({ ...prev, [team]: 0 }));
    setNewTeam("");
  };

  const startGame = () => {
    if (queue.length < 2) return;
    setKing(queue[0]);
    setQueen(queue[1]);
    setQueue(queue.slice(2));
  };

  const scorePoint = () => {
    if (!king) return;
    setPoints((prev) => ({ ...prev, [king]: prev[king] + 1 }));
  };

  const sideOut = () => {
    if (!queen) return;
    const newKing = queen;
    const newQueen = queue.length > 0 ? queue[0] : null;
    const newQueue = queue.length > 0 ? [...queue.slice(1), king] : [king];
    setKing(newKing);
    setQueen(newQueen);
    setQueue(newQueue);
  };

  return (
    <div style={{ padding: "20px", maxWidth: "600px", margin: "auto" }}>
      <h1>King of the Court – Tracker</h1>
      <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
        <button onClick={saveGame}>💾 Speichern</button>
        <button onClick={clearGame}>🗑️ Löschen</button>
      </div>
      <div>
        <h2>Teams hinzufügen</h2>
        <input value={newTeam} onChange={(e) => setNewTeam(e.target.value)} placeholder="Teamname" />
        <button onClick={addTeam}>Hinzufügen</button>
        <h3>Teams</h3>
        {teams.map((t) => <div key={t}>• {t}</div>)}
        <button onClick={startGame} disabled={teams.length < 2} style={{ marginTop: "10px" }}>
          Spiel starten
        </button>
      </div>
      <div style={{ marginTop: "30px" }}>
        <h2>Spielfeld</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", textAlign: "center" }}>
          <div style={{ padding: "15px", background: "#ffe88a" }}>
            <h3>King</h3>
            <p>{king || "—"}</p>
            {king && <p>Punkte: {points[king]}</p>}
          </div>
          <div style={{ padding: "15px", background: "#b8d7ff" }}>
            <h3>Queen</h3>
            <p>{queen || "—"}</p>
          </div>
        </div>
        <div style={{ marginTop: "20px", display: "flex", gap: "10px" }}>
          <button onClick={scorePoint}>Punkt King</button>
          <button onClick={sideOut}>Side-Out</button>
        </div>
      </div>
      <div style={{ marginTop: "30px" }}>
        <h2>Warteschlange</h2>
        {queue.length === 0 && <p>Keine Teams.</p>}
        {queue.map((t) => <div key={t}>{t}</div>)}
      </div>
    </div>
  );
}
